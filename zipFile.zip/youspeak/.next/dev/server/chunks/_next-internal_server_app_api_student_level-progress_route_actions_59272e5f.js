module.exports = [
"[project]/.next-internal/server/app/api/student/level-progress/route/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=_next-internal_server_app_api_student_level-progress_route_actions_59272e5f.js.map