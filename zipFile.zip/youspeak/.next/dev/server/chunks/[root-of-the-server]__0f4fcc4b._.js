module.exports = [
"[externals]/next/dist/compiled/next-server/app-route-turbo.runtime.dev.js [external] (next/dist/compiled/next-server/app-route-turbo.runtime.dev.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/compiled/next-server/app-route-turbo.runtime.dev.js", () => require("next/dist/compiled/next-server/app-route-turbo.runtime.dev.js"));

module.exports = mod;
}),
"[externals]/next/dist/compiled/@opentelemetry/api [external] (next/dist/compiled/@opentelemetry/api, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/compiled/@opentelemetry/api", () => require("next/dist/compiled/@opentelemetry/api"));

module.exports = mod;
}),
"[externals]/next/dist/compiled/next-server/app-page-turbo.runtime.dev.js [external] (next/dist/compiled/next-server/app-page-turbo.runtime.dev.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js", () => require("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/work-unit-async-storage.external.js [external] (next/dist/server/app-render/work-unit-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/work-unit-async-storage.external.js", () => require("next/dist/server/app-render/work-unit-async-storage.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/work-async-storage.external.js [external] (next/dist/server/app-render/work-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/work-async-storage.external.js", () => require("next/dist/server/app-render/work-async-storage.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/shared/lib/no-fallback-error.external.js [external] (next/dist/shared/lib/no-fallback-error.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/shared/lib/no-fallback-error.external.js", () => require("next/dist/shared/lib/no-fallback-error.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/after-task-async-storage.external.js [external] (next/dist/server/app-render/after-task-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/after-task-async-storage.external.js", () => require("next/dist/server/app-render/after-task-async-storage.external.js"));

module.exports = mod;
}),
"[externals]/util [external] (util, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("util", () => require("util"));

module.exports = mod;
}),
"[externals]/url [external] (url, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("url", () => require("url"));

module.exports = mod;
}),
"[externals]/http [external] (http, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("http", () => require("http"));

module.exports = mod;
}),
"[externals]/crypto [external] (crypto, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("crypto", () => require("crypto"));

module.exports = mod;
}),
"[externals]/assert [external] (assert, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("assert", () => require("assert"));

module.exports = mod;
}),
"[externals]/querystring [external] (querystring, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("querystring", () => require("querystring"));

module.exports = mod;
}),
"[externals]/buffer [external] (buffer, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("buffer", () => require("buffer"));

module.exports = mod;
}),
"[externals]/zlib [external] (zlib, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("zlib", () => require("zlib"));

module.exports = mod;
}),
"[externals]/https [external] (https, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("https", () => require("https"));

module.exports = mod;
}),
"[externals]/events [external] (events, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("events", () => require("events"));

module.exports = mod;
}),
"[externals]/@prisma/client [external] (@prisma/client, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("@prisma/client", () => require("@prisma/client"));

module.exports = mod;
}),
"[project]/lib/prisma.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "prisma",
    ()=>prisma
]);
var __TURBOPACK__imported__module__$5b$externals$5d2f40$prisma$2f$client__$5b$external$5d$__$2840$prisma$2f$client$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/@prisma/client [external] (@prisma/client, cjs)");
;
const globalForPrisma = globalThis;
function getMongoDBUri() {
    const uri = process.env.MONGODB_URI || '';
    if (uri.includes('mongodb.net/') || uri.includes('mongodb://')) {
        const parts = uri.split('mongodb.net/');
        if (parts.length === 2) {
            const afterHost = parts[1];
            const dbName = afterHost.split('?')[0];
            if (!dbName || dbName.length === 0) {
                const queryParams = afterHost.includes('?') ? afterHost.substring(afterHost.indexOf('?')) : '';
                return parts[0] + 'mongodb.net/youspeak' + queryParams;
            }
        }
    }
    return uri;
}
const databaseUrl = getMongoDBUri();
if (databaseUrl !== process.env.MONGODB_URI) {
    console.log('✅ MongoDB database name added: youspeak');
}
const prisma = globalForPrisma.prisma ?? new __TURBOPACK__imported__module__$5b$externals$5d2f40$prisma$2f$client__$5b$external$5d$__$2840$prisma$2f$client$2c$__cjs$29$__["PrismaClient"]({
    datasources: {
        db: {
            url: databaseUrl
        }
    }
});
if ("TURBOPACK compile-time truthy", 1) globalForPrisma.prisma = prisma;
}),
"[project]/lib/auth.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "authOptions",
    ()=>authOptions
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$auth$2f$providers$2f$credentials$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next-auth/providers/credentials.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$prisma$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/prisma.ts [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$bcryptjs$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/bcryptjs/index.js [app-route] (ecmascript)");
;
;
;
const authOptions = {
    providers: [
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$auth$2f$providers$2f$credentials$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["default"])({
            name: 'credentials',
            credentials: {
                emailOrPhone: {
                    label: 'Email or Phone',
                    type: 'text'
                },
                password: {
                    label: 'Password',
                    type: 'password'
                }
            },
            async authorize (credentials) {
                console.log('🔐 Login attempt:', credentials?.emailOrPhone);
                if (!credentials?.emailOrPhone || !credentials?.password) {
                    console.log('❌ Missing credentials');
                    throw new Error('Invalid credentials');
                }
                const isEmail = credentials.emailOrPhone.includes('@');
                const user = await __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$prisma$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["prisma"].user.findFirst({
                    where: isEmail ? {
                        email: credentials.emailOrPhone
                    } : {
                        phone: credentials.emailOrPhone
                    },
                    include: {
                        StudentProfile: true,
                        TeacherProfile: true
                    }
                });
                if (!user) {
                    console.log('❌ User not found:', credentials.emailOrPhone);
                    throw new Error('Invalid credentials');
                }
                if (!user.passwordHash) {
                    console.log('❌ No password hash for user:', credentials.emailOrPhone);
                    throw new Error('Invalid credentials');
                }
                console.log('✅ User found:', user.email, 'Role:', user.role, 'Active:', user.isActive);
                const isPasswordValid = await __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$bcryptjs$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["default"].compare(credentials.password, user.passwordHash);
                if (!isPasswordValid) {
                    console.log('❌ Invalid password for:', credentials.emailOrPhone);
                    throw new Error('Invalid credentials');
                }
                console.log('✅ Password valid');
                console.log('✅ Login successful for:', user.email);
                return {
                    id: user.id,
                    email: user.email,
                    name: user.name,
                    role: user.role,
                    isActive: user.isActive
                };
            }
        })
    ],
    session: {
        strategy: 'jwt',
        maxAge: 90 * 24 * 60 * 60
    },
    pages: {
        signIn: '/auth/login',
        error: '/auth/error'
    },
    callbacks: {
        async jwt ({ token, user }) {
            if (user) {
                token.id = user.id;
                token.role = user.role;
                token.isActive = user.isActive;
            }
            return token;
        },
        async session ({ session, token }) {
            if (session.user) {
                session.user.id = token.id;
                session.user.role = token.role;
                session.user.isActive = token.isActive;
            }
            return session;
        }
    },
    secret: ("TURBOPACK compile-time value", "youspeak-nextauth-secret-key-2024")
};
}),
"[project]/lib/gamification.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "DEFAULT_BADGES",
    ()=>DEFAULT_BADGES,
    "XP_REWARDS",
    ()=>XP_REWARDS,
    "addXP",
    ()=>addXP,
    "calculateLevelFromXP",
    ()=>calculateLevelFromXP,
    "calculateXPForLevel",
    ()=>calculateXPForLevel,
    "checkAndAwardBadges",
    ()=>checkAndAwardBadges,
    "getLeaderboard",
    ()=>getLeaderboard,
    "getLevelTitle",
    ()=>getLevelTitle,
    "getOrCreateUserGamification",
    ()=>getOrCreateUserGamification,
    "getUserRank",
    ()=>getUserRank,
    "getUserStats",
    ()=>getUserStats,
    "initializeDefaultBadges",
    ()=>initializeDefaultBadges,
    "updateStreak",
    ()=>updateStreak
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$prisma$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/prisma.ts [app-route] (ecmascript)");
;
const XP_REWARDS = {
    // الكلمات
    WORD_LEARNED: 10,
    WORD_REVIEWED: 5,
    WORD_MASTERED: 25,
    // الدروس
    LESSON_COMPLETED: 50,
    EXERCISE_CORRECT: 10,
    EXERCISE_PERFECT: 20,
    // الكتابة
    WRITING_SUBMITTED: 30,
    WRITING_GRADED: 20,
    WRITING_EXCELLENT: 50,
    // الحضور
    DAILY_LOGIN: 15,
    STREAK_BONUS: 5,
    // الإنجازات
    FIRST_WORD: 50,
    FIRST_LESSON: 100,
    FIRST_WRITING: 75,
    // الجلسات
    SESSION_ATTENDED: 100,
    HOMEWORK_SUBMITTED: 40,
    // المحادثة
    CONVERSATION_COMPLETED: 35,
    LISTENING_COMPLETED: 30
};
function calculateXPForLevel(level) {
    // صيغة: المستوى 1 = 100 XP، كل مستوى يزيد بـ 50%
    return Math.floor(100 * Math.pow(1.5, level - 1));
}
function calculateLevelFromXP(totalXP) {
    let level = 1;
    let xpNeeded = calculateXPForLevel(1);
    let remainingXP = totalXP;
    while(remainingXP >= xpNeeded){
        remainingXP -= xpNeeded;
        level++;
        xpNeeded = calculateXPForLevel(level);
    }
    return {
        level,
        currentLevelXP: remainingXP,
        xpToNextLevel: xpNeeded
    };
}
function getLevelTitle(level, lang = 'ar') {
    const titles = {
        en: [
            {
                min: 1,
                max: 5,
                title: 'Beginner'
            },
            {
                min: 6,
                max: 10,
                title: 'Learner'
            },
            {
                min: 11,
                max: 15,
                title: 'Explorer'
            },
            {
                min: 16,
                max: 20,
                title: 'Achiever'
            },
            {
                min: 21,
                max: 30,
                title: 'Expert'
            },
            {
                min: 31,
                max: 40,
                title: 'Master'
            },
            {
                min: 41,
                max: 50,
                title: 'Champion'
            },
            {
                min: 51,
                max: 100,
                title: 'Legend'
            }
        ],
        ar: [
            {
                min: 1,
                max: 5,
                title: 'مبتدئ'
            },
            {
                min: 6,
                max: 10,
                title: 'متعلم'
            },
            {
                min: 11,
                max: 15,
                title: 'مستكشف'
            },
            {
                min: 16,
                max: 20,
                title: 'منجز'
            },
            {
                min: 21,
                max: 30,
                title: 'خبير'
            },
            {
                min: 31,
                max: 40,
                title: 'محترف'
            },
            {
                min: 41,
                max: 50,
                title: 'بطل'
            },
            {
                min: 51,
                max: 100,
                title: 'أسطورة'
            }
        ]
    };
    const titleList = titles[lang];
    const found = titleList.find((t)=>level >= t.min && level <= t.max);
    return found?.title || (lang === 'ar' ? 'أسطورة' : 'Legend');
}
async function getOrCreateUserGamification(userId) {
    let gamification = await __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$prisma$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["prisma"].userGamification.findUnique({
        where: {
            userId
        },
        include: {
            userBadges: {
                include: {
                    Badge: true
                }
            }
        }
    });
    if (!gamification) {
        gamification = await __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$prisma$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["prisma"].userGamification.create({
            data: {
                userId,
                totalXP: 0,
                currentLevel: 1,
                currentLevelXP: 0,
                xpToNextLevel: 100,
                totalPoints: 0,
                currentStreak: 0,
                longestStreak: 0
            },
            include: {
                userBadges: {
                    include: {
                        Badge: true
                    }
                }
            }
        });
    }
    return gamification;
}
async function addXP(userId, xpAmount, reason, activityType) {
    const gamification = await getOrCreateUserGamification(userId);
    const newTotalXP = gamification.totalXP + xpAmount;
    const { level, currentLevelXP, xpToNextLevel } = calculateLevelFromXP(newTotalXP);
    const leveledUp = level > gamification.currentLevel;
    // تحديث الإحصائيات حسب نوع النشاط
    const updateData = {
        totalXP: newTotalXP,
        currentLevel: level,
        currentLevelXP: currentLevelXP,
        xpToNextLevel: xpToNextLevel,
        totalPoints: gamification.totalPoints + Math.floor(xpAmount / 2)
    };
    if (activityType === 'word') {
        updateData.wordsLearned = gamification.wordsLearned + 1;
    } else if (activityType === 'lesson') {
        updateData.lessonsCompleted = gamification.lessonsCompleted + 1;
    } else if (activityType === 'exercise') {
        updateData.exercisesCompleted = gamification.exercisesCompleted + 1;
    } else if (activityType === 'writing') {
        updateData.writingsSubmitted = gamification.writingsSubmitted + 1;
    }
    const updated = await __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$prisma$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["prisma"].userGamification.update({
        where: {
            id: gamification.id
        },
        data: updateData,
        include: {
            userBadges: {
                include: {
                    Badge: true
                }
            }
        }
    });
    // تحديث النشاط اليومي
    await updateDailyActivity(gamification.id, xpAmount, activityType);
    // التحقق من الشارات الجديدة
    await checkAndAwardBadges(userId);
    return {
        gamification: updated,
        xpAdded: xpAmount,
        leveledUp,
        newLevel: leveledUp ? level : null,
        reason
    };
}
// تحديث النشاط اليومي
async function updateDailyActivity(gamificationId, xpEarned, activityType) {
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const updateData = {
        xpEarned: {
            increment: xpEarned
        },
        pointsEarned: {
            increment: Math.floor(xpEarned / 2)
        },
        activitiesCount: {
            increment: 1
        }
    };
    if (activityType === 'word') {
        updateData.wordsLearned = {
            increment: 1
        };
    } else if (activityType === 'lesson') {
        updateData.lessonsCompleted = {
            increment: 1
        };
    } else if (activityType === 'exercise') {
        updateData.exercisesDone = {
            increment: 1
        };
    }
    await __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$prisma$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["prisma"].dailyActivity.upsert({
        where: {
            gamificationId_date: {
                gamificationId,
                date: today
            }
        },
        create: {
            gamificationId,
            date: today,
            xpEarned,
            pointsEarned: Math.floor(xpEarned / 2),
            activitiesCount: 1,
            wordsLearned: activityType === 'word' ? 1 : 0,
            lessonsCompleted: activityType === 'lesson' ? 1 : 0,
            exercisesDone: activityType === 'exercise' ? 1 : 0
        },
        update: updateData
    });
}
async function updateStreak(userId) {
    const gamification = await getOrCreateUserGamification(userId);
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const yesterday = new Date(today);
    yesterday.setDate(yesterday.getDate() - 1);
    let newStreak = gamification.currentStreak;
    let xpBonus = 0;
    if (!gamification.lastActiveDate) {
        newStreak = 1;
        xpBonus = XP_REWARDS.DAILY_LOGIN;
    } else {
        const lastActive = new Date(gamification.lastActiveDate);
        lastActive.setHours(0, 0, 0, 0);
        if (lastActive.getTime() === yesterday.getTime()) {
            newStreak = gamification.currentStreak + 1;
            xpBonus = XP_REWARDS.DAILY_LOGIN + newStreak * XP_REWARDS.STREAK_BONUS;
        } else if (lastActive.getTime() === today.getTime()) {
            return {
                streak: gamification.currentStreak,
                xpBonus: 0
            };
        } else {
            newStreak = 1;
            xpBonus = XP_REWARDS.DAILY_LOGIN;
        }
    }
    const newLongestStreak = Math.max(newStreak, gamification.longestStreak);
    const newTotalXP = gamification.totalXP + xpBonus;
    const { level, currentLevelXP, xpToNextLevel } = calculateLevelFromXP(newTotalXP);
    await __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$prisma$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["prisma"].userGamification.update({
        where: {
            id: gamification.id
        },
        data: {
            currentStreak: newStreak,
            longestStreak: newLongestStreak,
            lastActiveDate: today,
            totalXP: newTotalXP,
            currentLevel: level,
            currentLevelXP: currentLevelXP,
            xpToNextLevel: xpToNextLevel,
            totalPoints: gamification.totalPoints + Math.floor(xpBonus / 2)
        }
    });
    await checkAndAwardBadges(userId);
    return {
        streak: newStreak,
        xpBonus
    };
}
async function checkAndAwardBadges(userId) {
    const gamification = await getOrCreateUserGamification(userId);
    const earnedBadgeIds = gamification.userBadges.map((ub)=>ub.badgeId);
    // الحصول على جميع الشارات النشطة
    const allBadges = await __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$prisma$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["prisma"].badge.findMany({
        where: {
            isActive: true
        }
    });
    const newBadges = [];
    for (const badge of allBadges){
        if (earnedBadgeIds.includes(badge.id)) continue;
        const requirement = JSON.parse(badge.requirement);
        let earned = false;
        // التحقق من المتطلبات
        switch(requirement.type){
            case 'streak':
                earned = gamification.currentStreak >= requirement.value;
                break;
            case 'words':
                earned = gamification.wordsLearned >= requirement.value;
                break;
            case 'lessons':
                earned = gamification.lessonsCompleted >= requirement.value;
                break;
            case 'xp':
                earned = gamification.totalXP >= requirement.value;
                break;
            case 'level':
                earned = gamification.currentLevel >= requirement.value;
                break;
            case 'exercises':
                earned = gamification.exercisesCompleted >= requirement.value;
                break;
            case 'writings':
                earned = gamification.writingsSubmitted >= requirement.value;
                break;
            case 'perfect_scores':
                earned = gamification.perfectScores >= requirement.value;
                break;
        }
        if (earned) {
            await __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$prisma$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["prisma"].userBadge.create({
                data: {
                    gamificationId: gamification.id,
                    badgeId: badge.id
                }
            });
            if (badge.xpReward > 0) {
                const updatedGamification = await __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$prisma$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["prisma"].userGamification.findUnique({
                    where: {
                        id: gamification.id
                    }
                });
                if (updatedGamification) {
                    const newTotalXP = updatedGamification.totalXP + badge.xpReward;
                    const { level, currentLevelXP, xpToNextLevel } = calculateLevelFromXP(newTotalXP);
                    await __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$prisma$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["prisma"].userGamification.update({
                        where: {
                            id: gamification.id
                        },
                        data: {
                            totalXP: newTotalXP,
                            currentLevel: level,
                            currentLevelXP: currentLevelXP,
                            xpToNextLevel: xpToNextLevel,
                            totalPoints: updatedGamification.totalPoints + badge.pointsReward
                        }
                    });
                }
            }
            newBadges.push(badge);
        }
    }
    return newBadges;
}
async function getLeaderboard(limit = 20, type = 'xp') {
    const orderBy = type === 'xp' ? {
        totalXP: 'desc'
    } : type === 'streak' ? {
        currentStreak: 'desc'
    } : {
        currentLevel: 'desc'
    };
    const leaderboard = await __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$prisma$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["prisma"].userGamification.findMany({
        take: limit,
        orderBy,
        include: {
            User: {
                select: {
                    id: true,
                    name: true,
                    profilePhoto: true
                }
            }
        }
    });
    return leaderboard.map((entry, index)=>({
            rank: index + 1,
            userId: entry.userId,
            name: entry.User.name,
            profilePhoto: entry.User.profilePhoto,
            totalXP: entry.totalXP,
            currentLevel: entry.currentLevel,
            currentStreak: entry.currentStreak,
            levelTitle: getLevelTitle(entry.currentLevel)
        }));
}
async function getUserRank(userId) {
    const userGamification = await getOrCreateUserGamification(userId);
    const higherRanked = await __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$prisma$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["prisma"].userGamification.count({
        where: {
            totalXP: {
                gt: userGamification.totalXP
            }
        }
    });
    return higherRanked + 1;
}
const DEFAULT_BADGES = [
    // شارات الـ Streak
    {
        name: 'First Day',
        nameAr: 'اليوم الأول',
        description: 'Complete your first day of learning',
        descriptionAr: 'أكمل يومك الأول من التعلم',
        icon: '🌟',
        category: 'STREAK',
        requirement: JSON.stringify({
            type: 'streak',
            value: 1
        }),
        xpReward: 50,
        pointsReward: 25,
        rarity: 'COMMON',
        order: 1
    },
    {
        name: 'Week Warrior',
        nameAr: 'محارب الأسبوع',
        description: 'Maintain a 7-day streak',
        descriptionAr: 'حافظ على سلسلة 7 أيام',
        icon: '🔥',
        category: 'STREAK',
        requirement: JSON.stringify({
            type: 'streak',
            value: 7
        }),
        xpReward: 150,
        pointsReward: 75,
        rarity: 'UNCOMMON',
        order: 2
    },
    {
        name: 'Month Master',
        nameAr: 'سيد الشهر',
        description: 'Maintain a 30-day streak',
        descriptionAr: 'حافظ على سلسلة 30 يوم',
        icon: '💪',
        category: 'STREAK',
        requirement: JSON.stringify({
            type: 'streak',
            value: 30
        }),
        xpReward: 500,
        pointsReward: 250,
        rarity: 'RARE',
        order: 3
    },
    {
        name: 'Century Streak',
        nameAr: 'سلسلة المائة',
        description: 'Maintain a 100-day streak',
        descriptionAr: 'حافظ على سلسلة 100 يوم',
        icon: '🏆',
        category: 'STREAK',
        requirement: JSON.stringify({
            type: 'streak',
            value: 100
        }),
        xpReward: 2000,
        pointsReward: 1000,
        rarity: 'LEGENDARY',
        order: 4
    },
    // شارات الكلمات
    {
        name: 'Word Beginner',
        nameAr: 'مبتدئ الكلمات',
        description: 'Learn 10 words',
        descriptionAr: 'تعلم 10 كلمات',
        icon: '📚',
        category: 'LEARNING',
        requirement: JSON.stringify({
            type: 'words',
            value: 10
        }),
        xpReward: 50,
        pointsReward: 25,
        rarity: 'COMMON',
        order: 5
    },
    {
        name: 'Vocabulary Builder',
        nameAr: 'بانٍ المفردات',
        description: 'Learn 50 words',
        descriptionAr: 'تعلم 50 كلمة',
        icon: '📖',
        category: 'LEARNING',
        requirement: JSON.stringify({
            type: 'words',
            value: 50
        }),
        xpReward: 200,
        pointsReward: 100,
        rarity: 'UNCOMMON',
        order: 6
    },
    {
        name: 'Word Master',
        nameAr: 'سيد الكلمات',
        description: 'Learn 200 words',
        descriptionAr: 'تعلم 200 كلمة',
        icon: '🎓',
        category: 'LEARNING',
        requirement: JSON.stringify({
            type: 'words',
            value: 200
        }),
        xpReward: 500,
        pointsReward: 250,
        rarity: 'RARE',
        order: 7
    },
    {
        name: 'Lexicon Legend',
        nameAr: 'أسطورة المعجم',
        description: 'Learn 500 words',
        descriptionAr: 'تعلم 500 كلمة',
        icon: '👑',
        category: 'LEARNING',
        requirement: JSON.stringify({
            type: 'words',
            value: 500
        }),
        xpReward: 1500,
        pointsReward: 750,
        rarity: 'LEGENDARY',
        order: 8
    },
    // شارات المستوى
    {
        name: 'Rising Star',
        nameAr: 'نجم صاعد',
        description: 'Reach level 5',
        descriptionAr: 'وصل للمستوى 5',
        icon: '⭐',
        category: 'ACHIEVEMENT',
        requirement: JSON.stringify({
            type: 'level',
            value: 5
        }),
        xpReward: 100,
        pointsReward: 50,
        rarity: 'COMMON',
        order: 9
    },
    {
        name: 'Double Digits',
        nameAr: 'الأرقام المزدوجة',
        description: 'Reach level 10',
        descriptionAr: 'وصل للمستوى 10',
        icon: '🌟',
        category: 'ACHIEVEMENT',
        requirement: JSON.stringify({
            type: 'level',
            value: 10
        }),
        xpReward: 300,
        pointsReward: 150,
        rarity: 'UNCOMMON',
        order: 10
    },
    {
        name: 'Quarter Century',
        nameAr: 'ربع قرن',
        description: 'Reach level 25',
        descriptionAr: 'وصل للمستوى 25',
        icon: '💎',
        category: 'ACHIEVEMENT',
        requirement: JSON.stringify({
            type: 'level',
            value: 25
        }),
        xpReward: 750,
        pointsReward: 375,
        rarity: 'RARE',
        order: 11
    },
    {
        name: 'Half Century',
        nameAr: 'نصف قرن',
        description: 'Reach level 50',
        descriptionAr: 'وصل للمستوى 50',
        icon: '🏅',
        category: 'ACHIEVEMENT',
        requirement: JSON.stringify({
            type: 'level',
            value: 50
        }),
        xpReward: 2000,
        pointsReward: 1000,
        rarity: 'LEGENDARY',
        order: 12
    },
    // شارات الدروس
    {
        name: 'First Lesson',
        nameAr: 'الدرس الأول',
        description: 'Complete your first lesson',
        descriptionAr: 'أكمل درسك الأول',
        icon: '📝',
        category: 'LEARNING',
        requirement: JSON.stringify({
            type: 'lessons',
            value: 1
        }),
        xpReward: 50,
        pointsReward: 25,
        rarity: 'COMMON',
        order: 13
    },
    {
        name: 'Lesson Lover',
        nameAr: 'محب الدروس',
        description: 'Complete 10 lessons',
        descriptionAr: 'أكمل 10 دروس',
        icon: '📚',
        category: 'LEARNING',
        requirement: JSON.stringify({
            type: 'lessons',
            value: 10
        }),
        xpReward: 200,
        pointsReward: 100,
        rarity: 'UNCOMMON',
        order: 14
    },
    {
        name: 'Lesson Master',
        nameAr: 'سيد الدروس',
        description: 'Complete 50 lessons',
        descriptionAr: 'أكمل 50 درس',
        icon: '🎯',
        category: 'LEARNING',
        requirement: JSON.stringify({
            type: 'lessons',
            value: 50
        }),
        xpReward: 750,
        pointsReward: 375,
        rarity: 'EPIC',
        order: 15
    },
    // شارات الكتابة
    {
        name: 'First Words',
        nameAr: 'الكلمات الأولى',
        description: 'Submit your first writing',
        descriptionAr: 'قدم كتابتك الأولى',
        icon: '✍️',
        category: 'LEARNING',
        requirement: JSON.stringify({
            type: 'writings',
            value: 1
        }),
        xpReward: 75,
        pointsReward: 35,
        rarity: 'COMMON',
        order: 16
    },
    {
        name: 'Prolific Writer',
        nameAr: 'كاتب غزير',
        description: 'Submit 20 writings',
        descriptionAr: 'قدم 20 كتابة',
        icon: '📝',
        category: 'LEARNING',
        requirement: JSON.stringify({
            type: 'writings',
            value: 20
        }),
        xpReward: 400,
        pointsReward: 200,
        rarity: 'RARE',
        order: 17
    },
    // شارات XP
    {
        name: 'XP Hunter',
        nameAr: 'صياد الخبرة',
        description: 'Earn 1,000 XP',
        descriptionAr: 'اكسب 1,000 نقطة خبرة',
        icon: '💰',
        category: 'ACHIEVEMENT',
        requirement: JSON.stringify({
            type: 'xp',
            value: 1000
        }),
        xpReward: 100,
        pointsReward: 50,
        rarity: 'COMMON',
        order: 18
    },
    {
        name: 'XP Champion',
        nameAr: 'بطل الخبرة',
        description: 'Earn 10,000 XP',
        descriptionAr: 'اكسب 10,000 نقطة خبرة',
        icon: '🏆',
        category: 'ACHIEVEMENT',
        requirement: JSON.stringify({
            type: 'xp',
            value: 10000
        }),
        xpReward: 500,
        pointsReward: 250,
        rarity: 'RARE',
        order: 19
    },
    {
        name: 'XP Legend',
        nameAr: 'أسطورة الخبرة',
        description: 'Earn 50,000 XP',
        descriptionAr: 'اكسب 50,000 نقطة خبرة',
        icon: '👑',
        category: 'ACHIEVEMENT',
        requirement: JSON.stringify({
            type: 'xp',
            value: 50000
        }),
        xpReward: 2000,
        pointsReward: 1000,
        rarity: 'LEGENDARY',
        order: 20
    }
];
async function initializeDefaultBadges() {
    const existingBadges = await __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$prisma$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["prisma"].badge.count();
    if (existingBadges === 0) {
        for (const badge of DEFAULT_BADGES){
            await __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$prisma$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["prisma"].badge.create({
                data: badge
            });
        }
        console.log('✅ Default badges initialized');
    }
    return await __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$prisma$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["prisma"].badge.findMany({
        orderBy: {
            order: 'asc'
        }
    });
}
async function getUserStats(userId) {
    const gamification = await getOrCreateUserGamification(userId);
    const rank = await getUserRank(userId);
    const levelTitle = getLevelTitle(gamification.currentLevel);
    return {
        ...gamification,
        rank,
        levelTitle,
        levelTitleEn: getLevelTitle(gamification.currentLevel, 'en'),
        xpProgress: Math.round(gamification.currentLevelXP / gamification.xpToNextLevel * 100)
    };
}
}),
"[project]/app/api/gamification/stats/route.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "GET",
    ()=>GET
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/server.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$auth$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next-auth/index.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$auth$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/auth.ts [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$gamification$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/gamification.ts [app-route] (ecmascript)");
;
;
;
;
async function GET(request) {
    try {
        const session = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$auth$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["getServerSession"])(__TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$auth$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["authOptions"]);
        if (!session?.user?.id) {
            return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
                error: 'Unauthorized'
            }, {
                status: 401
            });
        }
        await (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$gamification$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["initializeDefaultBadges"])();
        const streakResult = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$gamification$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["updateStreak"])(session.user.id);
        const stats = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$gamification$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["getUserStats"])(session.user.id);
        return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
            success: true,
            stats,
            streakUpdated: streakResult.xpBonus > 0,
            streakBonus: streakResult.xpBonus
        });
    } catch (error) {
        console.error('Error fetching gamification stats:', error);
        return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
            error: 'Failed to fetch stats'
        }, {
            status: 500
        });
    }
}
}),
];

//# sourceMappingURL=%5Broot-of-the-server%5D__0f4fcc4b._.js.map