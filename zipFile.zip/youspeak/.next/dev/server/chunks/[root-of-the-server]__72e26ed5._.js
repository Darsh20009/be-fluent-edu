module.exports = [
"[externals]/next/dist/compiled/next-server/app-route-turbo.runtime.dev.js [external] (next/dist/compiled/next-server/app-route-turbo.runtime.dev.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/compiled/next-server/app-route-turbo.runtime.dev.js", () => require("next/dist/compiled/next-server/app-route-turbo.runtime.dev.js"));

module.exports = mod;
}),
"[externals]/next/dist/compiled/@opentelemetry/api [external] (next/dist/compiled/@opentelemetry/api, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/compiled/@opentelemetry/api", () => require("next/dist/compiled/@opentelemetry/api"));

module.exports = mod;
}),
"[externals]/next/dist/compiled/next-server/app-page-turbo.runtime.dev.js [external] (next/dist/compiled/next-server/app-page-turbo.runtime.dev.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js", () => require("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/work-unit-async-storage.external.js [external] (next/dist/server/app-render/work-unit-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/work-unit-async-storage.external.js", () => require("next/dist/server/app-render/work-unit-async-storage.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/work-async-storage.external.js [external] (next/dist/server/app-render/work-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/work-async-storage.external.js", () => require("next/dist/server/app-render/work-async-storage.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/shared/lib/no-fallback-error.external.js [external] (next/dist/shared/lib/no-fallback-error.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/shared/lib/no-fallback-error.external.js", () => require("next/dist/shared/lib/no-fallback-error.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/after-task-async-storage.external.js [external] (next/dist/server/app-render/after-task-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/after-task-async-storage.external.js", () => require("next/dist/server/app-render/after-task-async-storage.external.js"));

module.exports = mod;
}),
"[externals]/util [external] (util, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("util", () => require("util"));

module.exports = mod;
}),
"[externals]/url [external] (url, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("url", () => require("url"));

module.exports = mod;
}),
"[externals]/http [external] (http, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("http", () => require("http"));

module.exports = mod;
}),
"[externals]/crypto [external] (crypto, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("crypto", () => require("crypto"));

module.exports = mod;
}),
"[externals]/assert [external] (assert, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("assert", () => require("assert"));

module.exports = mod;
}),
"[externals]/querystring [external] (querystring, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("querystring", () => require("querystring"));

module.exports = mod;
}),
"[externals]/buffer [external] (buffer, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("buffer", () => require("buffer"));

module.exports = mod;
}),
"[externals]/zlib [external] (zlib, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("zlib", () => require("zlib"));

module.exports = mod;
}),
"[externals]/https [external] (https, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("https", () => require("https"));

module.exports = mod;
}),
"[externals]/events [external] (events, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("events", () => require("events"));

module.exports = mod;
}),
"[externals]/@prisma/client [external] (@prisma/client, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("@prisma/client", () => require("@prisma/client"));

module.exports = mod;
}),
"[project]/lib/prisma.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "prisma",
    ()=>prisma
]);
var __TURBOPACK__imported__module__$5b$externals$5d2f40$prisma$2f$client__$5b$external$5d$__$2840$prisma$2f$client$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/@prisma/client [external] (@prisma/client, cjs)");
;
const globalForPrisma = globalThis;
function getMongoDBUri() {
    const uri = process.env.MONGODB_URI || '';
    if (uri.includes('mongodb.net/') || uri.includes('mongodb://')) {
        const parts = uri.split('mongodb.net/');
        if (parts.length === 2) {
            const afterHost = parts[1];
            const dbName = afterHost.split('?')[0];
            if (!dbName || dbName.length === 0) {
                const queryParams = afterHost.includes('?') ? afterHost.substring(afterHost.indexOf('?')) : '';
                return parts[0] + 'mongodb.net/youspeak' + queryParams;
            }
        }
    }
    return uri;
}
const databaseUrl = getMongoDBUri();
if (databaseUrl !== process.env.MONGODB_URI) {
    console.log('✅ MongoDB database name added: youspeak');
}
const prisma = globalForPrisma.prisma ?? new __TURBOPACK__imported__module__$5b$externals$5d2f40$prisma$2f$client__$5b$external$5d$__$2840$prisma$2f$client$2c$__cjs$29$__["PrismaClient"]({
    datasources: {
        db: {
            url: databaseUrl
        }
    }
});
if ("TURBOPACK compile-time truthy", 1) globalForPrisma.prisma = prisma;
}),
"[project]/lib/auth.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "authOptions",
    ()=>authOptions
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$auth$2f$providers$2f$credentials$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next-auth/providers/credentials.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$prisma$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/prisma.ts [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$bcryptjs$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/bcryptjs/index.js [app-route] (ecmascript)");
;
;
;
const authOptions = {
    providers: [
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$auth$2f$providers$2f$credentials$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["default"])({
            name: 'credentials',
            credentials: {
                emailOrPhone: {
                    label: 'Email or Phone',
                    type: 'text'
                },
                password: {
                    label: 'Password',
                    type: 'password'
                }
            },
            async authorize (credentials) {
                console.log('🔐 Login attempt:', credentials?.emailOrPhone);
                if (!credentials?.emailOrPhone || !credentials?.password) {
                    console.log('❌ Missing credentials');
                    throw new Error('Invalid credentials');
                }
                const isEmail = credentials.emailOrPhone.includes('@');
                const user = await __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$prisma$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["prisma"].user.findFirst({
                    where: isEmail ? {
                        email: credentials.emailOrPhone
                    } : {
                        phone: credentials.emailOrPhone
                    },
                    include: {
                        StudentProfile: true,
                        TeacherProfile: true
                    }
                });
                if (!user) {
                    console.log('❌ User not found:', credentials.emailOrPhone);
                    throw new Error('Invalid credentials');
                }
                if (!user.passwordHash) {
                    console.log('❌ No password hash for user:', credentials.emailOrPhone);
                    throw new Error('Invalid credentials');
                }
                console.log('✅ User found:', user.email, 'Role:', user.role, 'Active:', user.isActive);
                const isPasswordValid = await __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$bcryptjs$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["default"].compare(credentials.password, user.passwordHash);
                if (!isPasswordValid) {
                    console.log('❌ Invalid password for:', credentials.emailOrPhone);
                    throw new Error('Invalid credentials');
                }
                console.log('✅ Password valid');
                console.log('✅ Login successful for:', user.email);
                return {
                    id: user.id,
                    email: user.email,
                    name: user.name,
                    role: user.role,
                    isActive: user.isActive
                };
            }
        })
    ],
    session: {
        strategy: 'jwt',
        maxAge: 90 * 24 * 60 * 60
    },
    pages: {
        signIn: '/auth/login',
        error: '/auth/error'
    },
    callbacks: {
        async jwt ({ token, user }) {
            if (user) {
                token.id = user.id;
                token.role = user.role;
                token.isActive = user.isActive;
            }
            return token;
        },
        async session ({ session, token }) {
            if (session.user) {
                session.user.id = token.id;
                session.user.role = token.role;
                session.user.isActive = token.isActive;
            }
            return session;
        }
    },
    secret: ("TURBOPACK compile-time value", "youspeak-nextauth-secret-key-2024")
};
}),
"[project]/lib/student-level-system.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "ENGLISH_LEVELS",
    ()=>ENGLISH_LEVELS,
    "LEVEL_COLORS",
    ()=>LEVEL_COLORS,
    "LEVEL_DESCRIPTIONS",
    ()=>LEVEL_DESCRIPTIONS,
    "LEVEL_THRESHOLDS",
    ()=>LEVEL_THRESHOLDS,
    "adjustStudentLevel",
    ()=>adjustStudentLevel,
    "autoAdjustLevelIfNeeded",
    ()=>autoAdjustLevelIfNeeded,
    "calculateStudentPerformanceMetrics",
    ()=>calculateStudentPerformanceMetrics,
    "getLevelSkillRequirements",
    ()=>getLevelSkillRequirements,
    "getRecommendationsForLevel",
    ()=>getRecommendationsForLevel,
    "getStudentLevelProgress",
    ()=>getStudentLevelProgress
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$prisma$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/prisma.ts [app-route] (ecmascript)");
;
const ENGLISH_LEVELS = [
    'A1',
    'A2',
    'B1',
    'B2',
    'C1'
];
const LEVEL_DESCRIPTIONS = {
    ar: {
        A1: 'مبتدئ',
        A2: 'أساسي',
        B1: 'متوسط',
        B2: 'فوق المتوسط',
        C1: 'متقدم'
    },
    en: {
        A1: 'Beginner',
        A2: 'Elementary',
        B1: 'Intermediate',
        B2: 'Upper Intermediate',
        C1: 'Advanced'
    }
};
const LEVEL_COLORS = {
    A1: {
        bg: 'bg-red-100',
        text: 'text-red-700',
        border: 'border-red-300'
    },
    A2: {
        bg: 'bg-orange-100',
        text: 'text-orange-700',
        border: 'border-orange-300'
    },
    B1: {
        bg: 'bg-yellow-100',
        text: 'text-yellow-700',
        border: 'border-yellow-300'
    },
    B2: {
        bg: 'bg-blue-100',
        text: 'text-blue-700',
        border: 'border-blue-300'
    },
    C1: {
        bg: 'bg-purple-100',
        text: 'text-purple-700',
        border: 'border-purple-300'
    }
};
const LEVEL_THRESHOLDS = {
    A1: {
        min: 0,
        max: 20
    },
    A2: {
        min: 21,
        max: 40
    },
    B1: {
        min: 41,
        max: 60
    },
    B2: {
        min: 61,
        max: 80
    },
    C1: {
        min: 81,
        max: 100
    }
};
function getLevelIndex(level) {
    return ENGLISH_LEVELS.indexOf(level);
}
function getLevelFromIndex(index) {
    if (index < 0) return ENGLISH_LEVELS[0];
    if (index >= ENGLISH_LEVELS.length) return ENGLISH_LEVELS[ENGLISH_LEVELS.length - 1];
    return ENGLISH_LEVELS[index];
}
function getLevelFromScore(score) {
    for (const [level, thresholds] of Object.entries(LEVEL_THRESHOLDS)){
        if (score >= thresholds.min && score <= thresholds.max) {
            return level;
        }
    }
    return 'A1';
}
function getProgressInLevel(score, level) {
    const thresholds = LEVEL_THRESHOLDS[level];
    const range = thresholds.max - thresholds.min;
    const progress = (score - thresholds.min) / range * 100;
    return Math.max(0, Math.min(100, progress));
}
async function calculateStudentPerformanceMetrics(studentId) {
    const [words, exerciseAttempts, lessonProgress, writings] = await Promise.all([
        __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$prisma$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["prisma"].word.findMany({
            where: {
                studentId
            },
            select: {
                known: true,
                correctCount: true,
                incorrectCount: true
            }
        }),
        __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$prisma$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["prisma"].exerciseAttempt.findMany({
            where: {
                studentId
            },
            select: {
                isCorrect: true
            }
        }),
        __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$prisma$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["prisma"].lessonProgress.findMany({
            where: {
                studentId
            },
            select: {
                completed: true,
                exercisesScore: true
            }
        }),
        __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$prisma$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["prisma"].freeWriting.findMany({
            where: {
                studentId,
                grade: {
                    not: null
                }
            },
            select: {
                grade: true
            }
        })
    ]);
    let wordsKnownPercentage = 0;
    let wordsCorrectRate = 0;
    if (words.length > 0) {
        wordsKnownPercentage = words.filter((w)=>w.known).length / words.length * 100;
        const totalAttempts = words.reduce((sum, w)=>sum + w.correctCount + w.incorrectCount, 0);
        const totalCorrect = words.reduce((sum, w)=>sum + w.correctCount, 0);
        wordsCorrectRate = totalAttempts > 0 ? totalCorrect / totalAttempts * 100 : 0;
    }
    let exercisesCorrectRate = 0;
    if (exerciseAttempts.length > 0) {
        exercisesCorrectRate = exerciseAttempts.filter((e)=>e.isCorrect).length / exerciseAttempts.length * 100;
    }
    let lessonsCompletionRate = 0;
    if (lessonProgress.length > 0) {
        lessonsCompletionRate = lessonProgress.filter((l)=>l.completed).length / lessonProgress.length * 100;
    }
    let writingAverageScore = 0;
    if (writings.length > 0) {
        writingAverageScore = writings.reduce((sum, w)=>sum + (w.grade || 0), 0) / writings.length;
    }
    const dataPoints = words.length + exerciseAttempts.length + lessonProgress.length + writings.length;
    const categoriesWithData = [
        words.length > 0 ? 1 : 0,
        exerciseAttempts.length > 0 ? 1 : 0,
        lessonProgress.length > 0 ? 1 : 0,
        writings.length > 0 ? 1 : 0
    ].reduce((a, b)=>a + b, 0);
    const weights = {
        wordsKnown: 0.15,
        wordsCorrect: 0.20,
        exercises: 0.30,
        lessons: 0.15,
        writing: 0.20
    };
    let overallScore = 0;
    let totalWeight = 0;
    if (words.length > 0) {
        overallScore += wordsKnownPercentage * weights.wordsKnown;
        overallScore += wordsCorrectRate * weights.wordsCorrect;
        totalWeight += weights.wordsKnown + weights.wordsCorrect;
    }
    if (exerciseAttempts.length > 0) {
        overallScore += exercisesCorrectRate * weights.exercises;
        totalWeight += weights.exercises;
    }
    if (lessonProgress.length > 0) {
        overallScore += lessonsCompletionRate * weights.lessons;
        totalWeight += weights.lessons;
    }
    if (writings.length > 0) {
        overallScore += writingAverageScore * weights.writing;
        totalWeight += weights.writing;
    }
    if (totalWeight > 0) {
        overallScore = overallScore / totalWeight;
    } else {
        overallScore = 0;
    }
    return {
        wordsKnownPercentage: Math.round(wordsKnownPercentage * 10) / 10,
        wordsCorrectRate: Math.round(wordsCorrectRate * 10) / 10,
        exercisesCorrectRate: Math.round(exercisesCorrectRate * 10) / 10,
        lessonsCompletionRate: Math.round(lessonsCompletionRate * 10) / 10,
        writingAverageScore: Math.round(writingAverageScore * 10) / 10,
        overallScore: Math.round(overallScore * 10) / 10,
        dataPoints
    };
}
async function getStudentLevelProgress(studentId) {
    const student = await __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$prisma$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["prisma"].studentProfile.findUnique({
        where: {
            userId: studentId
        },
        select: {
            levelInitial: true,
            levelCurrent: true,
            updatedAt: true
        }
    });
    if (!student) {
        return null;
    }
    const metrics = await calculateStudentPerformanceMetrics(studentId);
    const currentLevel = student.levelCurrent || student.levelInitial || 'A1';
    const initialLevel = student.levelInitial || 'A1';
    const suggestedLevel = getLevelFromScore(metrics.overallScore);
    const currentLevelIndex = getLevelIndex(currentLevel);
    const suggestedLevelIndex = getLevelIndex(suggestedLevel);
    const levelDifference = suggestedLevelIndex - currentLevelIndex;
    const shouldAdjust = Math.abs(levelDifference) >= 1 && metrics.dataPoints >= 20;
    const progressPercentage = getProgressInLevel(metrics.overallScore, currentLevel);
    return {
        currentLevel,
        initialLevel,
        performanceScore: metrics.overallScore,
        suggestedLevel,
        levelDifference,
        shouldAdjust,
        progressPercentage,
        metrics
    };
}
async function adjustStudentLevel(studentId, newLevel) {
    const student = await __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$prisma$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["prisma"].studentProfile.findUnique({
        where: {
            userId: studentId
        }
    });
    if (!student) {
        await __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$prisma$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["prisma"].studentProfile.create({
            data: {
                userId: studentId,
                levelInitial: newLevel,
                levelCurrent: newLevel
            }
        });
        return {
            success: true,
            previousLevel: 'NEW',
            newLevel
        };
    }
    const previousLevel = student.levelCurrent || student.levelInitial || 'A1';
    await __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$prisma$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["prisma"].studentProfile.update({
        where: {
            userId: studentId
        },
        data: {
            levelCurrent: newLevel,
            updatedAt: new Date()
        }
    });
    return {
        success: true,
        previousLevel,
        newLevel
    };
}
async function autoAdjustLevelIfNeeded(studentId) {
    const progress = await getStudentLevelProgress(studentId);
    if (!progress) {
        return {
            adjusted: false,
            reason: 'Student profile not found'
        };
    }
    if (progress.metrics.dataPoints < 20) {
        return {
            adjusted: false,
            reason: `Not enough data (${progress.metrics.dataPoints}/20 activities required)`
        };
    }
    if (!progress.shouldAdjust) {
        return {
            adjusted: false,
            reason: 'Performance matches current level'
        };
    }
    const result = await adjustStudentLevel(studentId, progress.suggestedLevel);
    return {
        adjusted: true,
        previousLevel: result.previousLevel,
        newLevel: result.newLevel,
        reason: progress.levelDifference > 0 ? 'Performance exceeds current level' : 'Performance below current level'
    };
}
function getRecommendationsForLevel(currentLevel, metrics, lang = 'ar') {
    const recommendations = [];
    if (lang === 'ar') {
        if (metrics.wordsCorrectRate < 70) {
            recommendations.push('راجع الكلمات التي تعلمتها بانتظام لتحسين التذكر');
        }
        if (metrics.exercisesCorrectRate < 60) {
            recommendations.push('أعد محاولة التمارين الصعبة وركز على القواعد');
        }
        if (metrics.lessonsCompletionRate < 50) {
            recommendations.push('أكمل المزيد من الدروس لتطوير مهاراتك');
        }
        if (metrics.writingAverageScore < 70 && metrics.dataPoints > 0) {
            recommendations.push('تدرب على الكتابة أكثر وتعلم من تعليقات المعلم');
        }
        if (metrics.overallScore > 80) {
            recommendations.push('أنت جاهز للانتقال للمستوى التالي!');
        }
    } else {
        if (metrics.wordsCorrectRate < 70) {
            recommendations.push('Review learned words regularly to improve retention');
        }
        if (metrics.exercisesCorrectRate < 60) {
            recommendations.push('Retry difficult exercises and focus on grammar rules');
        }
        if (metrics.lessonsCompletionRate < 50) {
            recommendations.push('Complete more lessons to develop your skills');
        }
        if (metrics.writingAverageScore < 70 && metrics.dataPoints > 0) {
            recommendations.push('Practice writing more and learn from teacher feedback');
        }
        if (metrics.overallScore > 80) {
            recommendations.push('You are ready to move to the next level!');
        }
    }
    if (recommendations.length === 0) {
        recommendations.push(lang === 'ar' ? 'استمر في التقدم! أنت تتحسن بشكل ممتاز' : 'Keep going! You are improving excellently');
    }
    return recommendations;
}
function getLevelSkillRequirements(level, lang = 'ar') {
    const requirements = {
        ar: {
            A1: {
                vocabulary: '500 كلمة أساسية',
                grammar: 'أساسيات الجمل البسيطة',
                speaking: 'تقديم النفس وتحيات بسيطة',
                listening: 'فهم كلمات وجمل قصيرة',
                writing: 'كتابة جمل بسيطة جداً'
            },
            A2: {
                vocabulary: '1000 كلمة',
                grammar: 'الأزمنة الأساسية والضمائر',
                speaking: 'محادثات يومية بسيطة',
                listening: 'فهم نصوص قصيرة واضحة',
                writing: 'فقرات قصيرة عن مواضيع مألوفة'
            },
            B1: {
                vocabulary: '2000 كلمة',
                grammar: 'الأزمنة المركبة والشرطية',
                speaking: 'مناقشة مواضيع متنوعة',
                listening: 'فهم البرامج والأفلام',
                writing: 'نصوص منظمة ومتماسكة'
            },
            B2: {
                vocabulary: '4000 كلمة',
                grammar: 'تراكيب معقدة ودقيقة',
                speaking: 'طلاقة في معظم المواقف',
                listening: 'فهم اللهجات المختلفة',
                writing: 'مقالات وتقارير مفصلة'
            },
            C1: {
                vocabulary: '8000+ كلمة',
                grammar: 'إتقان شامل للقواعد',
                speaking: 'طلاقة تامة وتعبير دقيق',
                listening: 'فهم كامل للمحتوى الأصلي',
                writing: 'كتابة أكاديمية ومهنية متقدمة'
            }
        },
        en: {
            A1: {
                vocabulary: '500 basic words',
                grammar: 'Basic simple sentences',
                speaking: 'Self-introduction and simple greetings',
                listening: 'Understand words and short sentences',
                writing: 'Write very simple sentences'
            },
            A2: {
                vocabulary: '1000 words',
                grammar: 'Basic tenses and pronouns',
                speaking: 'Simple daily conversations',
                listening: 'Understand short clear texts',
                writing: 'Short paragraphs on familiar topics'
            },
            B1: {
                vocabulary: '2000 words',
                grammar: 'Compound and conditional tenses',
                speaking: 'Discuss various topics',
                listening: 'Understand programs and movies',
                writing: 'Organized and coherent texts'
            },
            B2: {
                vocabulary: '4000 words',
                grammar: 'Complex and precise structures',
                speaking: 'Fluency in most situations',
                listening: 'Understand different accents',
                writing: 'Detailed essays and reports'
            },
            C1: {
                vocabulary: '8000+ words',
                grammar: 'Complete grammar mastery',
                speaking: 'Complete fluency and precise expression',
                listening: 'Full understanding of native content',
                writing: 'Advanced academic and professional writing'
            }
        }
    };
    return requirements[lang][level];
}
}),
"[project]/app/api/student/level-progress/route.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "GET",
    ()=>GET
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/server.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$auth$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next-auth/index.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$auth$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/auth.ts [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$student$2d$level$2d$system$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/student-level-system.ts [app-route] (ecmascript)");
;
;
;
;
async function GET(request) {
    try {
        const session = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$auth$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["getServerSession"])(__TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$auth$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["authOptions"]);
        if (!session || session.user.role !== 'STUDENT') {
            return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
                error: 'Unauthorized'
            }, {
                status: 401
            });
        }
        const studentId = session.user.id;
        const progress = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$student$2d$level$2d$system$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["getStudentLevelProgress"])(studentId);
        if (!progress) {
            return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
                success: false,
                error: 'Student profile not found. Please complete the placement test first.',
                needsPlacementTest: true
            });
        }
        const lang = request.nextUrl.searchParams.get('lang') === 'en' ? 'en' : 'ar';
        const recommendations = (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$student$2d$level$2d$system$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["getRecommendationsForLevel"])(progress.currentLevel, progress.metrics, lang);
        const skillRequirements = (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$student$2d$level$2d$system$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["getLevelSkillRequirements"])(progress.currentLevel, lang);
        return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
            success: true,
            currentLevel: progress.currentLevel,
            currentLevelName: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$student$2d$level$2d$system$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["LEVEL_DESCRIPTIONS"][lang][progress.currentLevel],
            initialLevel: progress.initialLevel,
            initialLevelName: progress.initialLevel ? __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$student$2d$level$2d$system$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["LEVEL_DESCRIPTIONS"][lang][progress.initialLevel] : null,
            performanceScore: progress.performanceScore,
            suggestedLevel: progress.suggestedLevel,
            suggestedLevelName: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$student$2d$level$2d$system$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["LEVEL_DESCRIPTIONS"][lang][progress.suggestedLevel],
            levelDifference: progress.levelDifference,
            shouldAdjust: progress.shouldAdjust,
            progressPercentage: progress.progressPercentage,
            metrics: progress.metrics,
            recommendations,
            skillRequirements,
            colors: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$student$2d$level$2d$system$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["LEVEL_COLORS"][progress.currentLevel],
            nextLevelColors: progress.levelDifference > 0 ? __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$student$2d$level$2d$system$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["LEVEL_COLORS"][progress.suggestedLevel] : null
        });
    } catch (error) {
        console.error('Error fetching level progress:', error);
        return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
            success: false,
            error: 'Failed to fetch level progress'
        }, {
            status: 500
        });
    }
}
}),
];

//# sourceMappingURL=%5Broot-of-the-server%5D__72e26ed5._.js.map