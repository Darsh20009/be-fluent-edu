(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[root-of-the-server]__28bc9c2a._.css",
  "static/chunks/components_SplashScreen_tsx_ec475c8d._.js",
  "static/chunks/node_modules_6eaa3acc._.js",
  "static/chunks/_8d23c462._.js"
],
    source: "dynamic"
});
