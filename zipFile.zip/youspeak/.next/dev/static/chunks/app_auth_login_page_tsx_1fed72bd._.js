(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_e5e5a47d._.js",
  "static/chunks/_6b0fc2b9._.js"
],
    source: "dynamic"
});
