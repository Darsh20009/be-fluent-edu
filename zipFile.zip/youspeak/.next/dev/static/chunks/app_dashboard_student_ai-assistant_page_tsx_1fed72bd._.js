(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_413b0b26._.js",
  "static/chunks/app_dashboard_student_ai-assistant_page_tsx_7bd069c3._.js"
],
    source: "dynamic"
});
