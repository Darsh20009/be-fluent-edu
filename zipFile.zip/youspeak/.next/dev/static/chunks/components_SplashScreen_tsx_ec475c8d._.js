(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/components/SplashScreen.tsx [app-client] (ecmascript, next/dynamic entry, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/node_modules_f6c9c943._.js",
  "static/chunks/components_SplashScreen_tsx_431d8631._.js",
  "static/chunks/components_SplashScreen_tsx_3d323f12._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/components/SplashScreen.tsx [app-client] (ecmascript, next/dynamic entry)");
    });
});
}),
]);