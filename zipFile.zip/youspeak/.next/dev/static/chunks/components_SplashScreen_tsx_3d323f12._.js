(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_f6c9c943._.js",
  "static/chunks/components_SplashScreen_tsx_431d8631._.js"
],
    source: "dynamic"
});
